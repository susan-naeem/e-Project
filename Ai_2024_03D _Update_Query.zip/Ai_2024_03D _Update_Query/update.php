<?php 
// Database Conection

$con = mysqli_connect("localhost","root","","ai_2025_03d");



if(isset($_GET['updateid'])){
    $id = $_GET['updateid'];

    //Fetch Data By ID
    $fechDataById = mysqli_query($con,"SELECT * FROM students WHERE id = $id");

    //Convert Data Into Array
    $value = mysqli_fetch_assoc($fechDataById);
?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <!-- Fontawesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/7.0.1/css/all.min.css" integrity="sha512-2SwdPD6INVrV/lHTZbO2nodKhrnDdJK9/kg2XD1r9uGqPo1cUbujc+IYdlYdEErWNu69gVcYgdxlmVmzTWnetw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <title>Hello, world!</title>


    <style>

.divider:after,
.divider:before {
content: "";
flex: 1;
height: 1px;
background: #eee;
}
.h-custom {
height: calc(100% - 73px);
}
@media (max-width: 450px) {
.h-custom {
height: 100%;
}
}

    </style>
  </head>
  <body>
  
  

  <section class="vh-100">
  <div class="container-fluid h-custom">
    <div class="row d-flex justify-content-center align-items-center h-100">
     
      <div class="col-md-8 col-lg-6 col-xl-4 offset-xl-1">
        <form action="connection.php"  method="post">
          

          <input type="hidden" name="id" value="<?php echo $value['id'] ?>">

           <!-- Name input -->
          <div data-mdb-input-init class="form-outline mb-4">
            <input type="text" name="name" value="<?php echo $value['name'] ?>" id="form3Example3" class="form-control form-control-lg"
              placeholder="Enter a valid name " />
            <label class="form-label" for="form3Example3">Full Name</label>
          </div>


          <!-- Email input -->
          <div data-mdb-input-init class="form-outline mb-4">
            <input type="email" name="email" value="<?php echo $value['email'] ?>"  id="form3Example3" class="form-control form-control-lg"
              placeholder="Enter a valid email address" />
            <label class="form-label" for="form3Example3">Email address</label>
          </div>

          <!-- Password input -->
          <div data-mdb-input-init class="form-outline mb-3">
            <input type="password" name="password" value="<?php echo $value['password'] ?>"  id="form3Example4" class="form-control form-control-lg"
              placeholder="Enter password" />
            <label class="form-label" for="form3Example4">Password</label>
          </div>


           <!-- Address input -->
          <div data-mdb-input-init class="form-outline mb-4">
            <input type="text" name="address" value="<?php echo $value['address'] ?>"  id="form3Example3" class="form-control form-control-lg"
              placeholder="Enter a valid address " />
            <label class="form-label" for="form3Example3">Enter Address Here</label>
          </div>


           <!-- Age input -->
          <div data-mdb-input-init class="form-outline mb-4">
            <input type="number" name="age" value="<?php echo $value['age'] ?>"  id="form3Example3" class="form-control form-control-lg"
              placeholder="Enter a valid Age " />
            <label class="form-label" for="form3Example3">Enter Age</label>
          </div>

          <div class="d-flex justify-content-between align-items-center">
           
            
          </div>

          <div class="text-center text-lg-start mt-4 pt-2">
            <!-- <button  type="submit" name="login" data-mdb-button-init data-mdb-ripple-init class="btn btn-primary btn-lg"
              style="padding-left: 2.5rem; padding-right: 2.5rem;">Login</button> -->


              <button  type="submit" name="update" data-mdb-button-init data-mdb-ripple-init class="btn btn-primary btn-lg"
              style="padding-left: 2.5rem; padding-right: 2.5rem;">Update</button>

           
          </div>

        </form>
      </div>
    </div>
  </div>
  <div
    class="d-flex flex-column flex-md-row text-center text-md-start justify-content-between py-4 px-4 px-xl-5 bg-primary">
    <!-- Copyright -->
    <div class="text-white mb-3 mb-md-0">
      Copyright © 2020. All rights reserved.
    </div>
    <!-- Copyright -->

    <!-- Right -->
    <div>
      <a href="#!" class="text-white me-4">
        <i class="fab fa-facebook-f"></i>
      </a>
      <a href="#!" class="text-white me-4">
        <i class="fab fa-twitter"></i>
      </a>
      <a href="#!" class="text-white me-4">
        <i class="fab fa-google"></i>
      </a>
      <a href="#!" class="text-white">
        <i class="fab fa-linkedin-in"></i>
      </a>
    </div>
    <!-- Right -->
  </div>
</section>
  





    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
  </body>
</html>

<?php 
    
}

?>
