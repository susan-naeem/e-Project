<?php
    $connect = mysqli_connect("localhost","root","","susandb1");

    if(isset($_POST['register'])){
        $name = $_POST['name'];
        $email = $_POST['email'];
        $password = $_POST['password'];
        $age = $_POST['age'];
        $adress = $_POST['adress'];
        $phone = $_POST['phone'];
         $dob = $_POST['dob'];

    

    $EmailAlreadyExists = mysqli_query($connect,"SELECT * FROM users WHERE email = '$email'");

    if(mysqli_num_rows($EmailAlreadyExists) > 0){
        ?>
        <script>
            alert("Email Already Exists");
            location.assign("form.php");
        </script>
        <?php
    }else{
        $InsertData = mysqli_query($connect,"INSERT INTO users(name,email,password,age,adress,dob) 
        VALUES ('$name','$email','$password','$age','$adress','$dob')");

        if($InsertData == true){
            ?>
            <script>
                alert("Registration Successful");
                location.assign("form.php")
            </script>
            <?php
        }
    
}
   }
?>
<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <title>Hello, world!</title>
</head>
<body>

<table class="table table-dark table-striped">
    <tr>
        <th>Name</th>
        <th>Email</th>
        <th>Password</th>
        <th>Age</th>
        <th>Adress</th>
        <th>Phone No</th>
        <th>DOB</th>
        <th>Action</th>
    </tr>

    <?php
   $GetData = mysqli_query($connect,"SELECT * FROM users");
    foreach($GetData as $data){
        ?>
        <tr>
            <td><?php echo $data['Name'] ?></td>
            <td><?php echo $data['Email'] ?></td>
            <td><?php echo $data['PASSWORD'] ?></td>
            <td><?php echo $data['Age'] ?></td>
            <td><?php echo $data['Adress'] ?></td>
            <td><?php echo $data['Phone_no'] ?></td>
            <td><?php echo $data['DOB'] ?></td>
            <td>
                <a href="connection.php?deleteID=<?php echo $data['id'] ?>" class="btn btn-danger">Delete</a>
            </td>
        </tr>
        <?php
    }
    ?>
  
</table>


<!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>


</body>

</html>
