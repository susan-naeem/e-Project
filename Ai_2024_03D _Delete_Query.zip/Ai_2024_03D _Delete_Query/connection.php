<?php 
// Database Conection

$con = mysqli_connect("localhost","root","","ai_2025_03d");


// Agar Register Button Pe Click Hota Hai
if(isset($_POST['register'])){

    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $address = $_POST['address'];
    $age = $_POST['age'];

    $EmailAlreadyExists = mysqli_query($con, "SELECT * FROM students WHERE email = '$email' ");

    if(mysqli_num_rows($EmailAlreadyExists) > 0){
    ?>
        <script>
            alert("Email Already Exists");
            location.assign("form-handling.php");
        </script>
        <?php 
    }else{
        $InsertData = mysqli_query($con, "INSERT INTO students (name, email, password, address, age) VALUES ('$name', '$email', '$password', '$address', '$age')");


        if($InsertData == true){

            ?>
                <script>
                    alert("Registration Successful");
                    location.assign("form-handling.php");
                </script>
            <?php
        }

    }
}


//Delete Work Here


if(isset($_GET['deleteid'])){
   $id = $_GET['deleteid'];

    $DeleteQuery = mysqli_query($con, "DELETE FROM students WHERE id = $id ");

    if($DeleteQuery == true){
        ?>
            <script>
                alert("Data Deleted Successfully");
                location.assign("connection.php");
            </script>
        <?php
    }
}
?>



<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<div class="m-5">
<table class="table table-striped">
    <tr>
        <th>Name</th>
        <th>Email</th>
        <th>Password</th>
        <th>Action</th>
    </tr>
    <?php 
        $GetAllData = mysqli_query($con, "SELECT * FROM students");

        // var_dump($GetAllData);

        foreach($GetAllData as $data){
            ?>
                <tr>
                    <td><?php echo $data['name'] ?></td>
                    <td><?php echo $data['email'] ?></td>
                    <td><?php echo $data['password'] ?></td>

                    <td>
                        <a href="connection.php?deleteid=<?php echo $data['id'] ?>" class="btn btn-danger">Delete</a>
                        <a href="" class="btn btn-success">Update</a>
                    </td>
                </tr>
            <?php
        }
    ?>



</table>
</div>



<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>