-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 25, 2025 at 10:11 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ai_2025_03d`
--

-- --------------------------------------------------------

--
-- Table structure for table `admission`
--

CREATE TABLE `admission` (
  `admission_id` int(11) NOT NULL,
  `course_name` varchar(50) DEFAULT NULL,
  `Batch_code` varchar(50) DEFAULT NULL,
  `faculty_name` varchar(50) DEFAULT NULL,
  `batch_timing` varchar(50) DEFAULT NULL,
  `student_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `category_id` int(11) NOT NULL,
  `category_name` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`category_id`, `category_name`) VALUES
(1, 'Men'),
(2, 'Women');

-- --------------------------------------------------------

--
-- Stand-in structure for view `orderandshipmentstatus`
-- (See below for the actual view)
--
CREATE TABLE `orderandshipmentstatus` (
`name` varchar(50)
,`order_id` int(11)
,`product_name` varchar(50)
,`product_qty` int(11)
,`product_price` int(11)
,`user_id` int(11)
,`shipment_status` varchar(50)
);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `order_id` int(11) NOT NULL,
  `product_name` varchar(50) DEFAULT NULL,
  `product_qty` int(11) DEFAULT NULL,
  `product_price` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `product_id` int(11) NOT NULL,
  `product_name` varchar(50) DEFAULT NULL,
  `product_desc` varchar(50) DEFAULT NULL,
  `product_qty` int(11) DEFAULT NULL,
  `product_price` int(11) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`product_id`, `product_name`, `product_desc`, `product_qty`, `product_price`, `category_id`) VALUES
(1, 'Women Saari', 'Best Quality', 100, 7000, 2),
(2, 'T Shirt', 'Best Quality', 100, 2500, 1),
(3, 'Jeans ', 'Best Quality', 100, 2000, 1);

-- --------------------------------------------------------

--
-- Stand-in structure for view `productstock`
-- (See below for the actual view)
--
CREATE TABLE `productstock` (
`category_name` varchar(50)
,`product_id` int(11)
,`product_name` varchar(50)
,`product_desc` varchar(50)
,`product_qty` int(11)
,`product_price` int(11)
,`category_id` int(11)
);

-- --------------------------------------------------------

--
-- Table structure for table `registers`
--

CREATE TABLE `registers` (
  `rollno` int(11) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `cnic` varchar(50) DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `city` varchar(50) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `registers`
--

INSERT INTO `registers` (`rollno`, `name`, `email`, `password`, `cnic`, `age`, `city`, `date`) VALUES
(6, 'Ali Khan', 'admin@gmail.com', 'admin@123', '35202-1234567-1', 22, 'Lahore', '2025-11-06 08:41:06'),
(7, 'Eshan', 'Eshan@gmail.com', 'Eshan123', '42201-9876543-2', 24, 'Karachi', '2025-10-03 08:35:06'),
(8, 'Usman Malik', 'usman.malik@hotmail.com', 'Usman@123', '61101-4567890-3', 27, 'Islamabad', '2025-10-15 07:00:00'),
(9, 'Fatima Noor', 'fatima.noor@gmail.com', 'Fatima@123', '37405-1122334-4', 21, 'Faisalabad', '2025-10-12 07:00:00'),
(10, 'Bilal Hussain', 'bilal.hussain@gmail.com', 'Bilal@123', '71102-5566778-5', 25, 'Hyderabad', '2025-10-20 07:00:00'),
(11, 'Sara Shah', 'sara.shah@gmail.com', 'Sara@123', '35201-8899001-6', 23, 'Lahore', '2025-09-14 07:00:00'),
(12, 'Hamza Tariq', 'hamza.tariq@gmail.com', 'Hamza@123', '61101-9988776-7', 26, 'Islamabad', '2025-10-23 07:00:00'),
(13, 'Zainab Ali', 'zainab.ali@yahoo.com', 'Zainab@123', '42201-3344556-8', 24, 'Karachi', '2025-09-14 07:00:00'),
(14, 'Ahmad Raza', 'ahmad.raza@gmail.com', 'Ahmad@123', '35202-6677889-9', 28, 'Lahore', '2025-10-23 07:00:00'),
(15, 'Mariam Khan', 'mariam.khan@gmail.com', 'Mariam@123', '37405-4455667-0', 22, 'Multan', '2025-08-24 07:00:00'),
(16, 'Imran Abbas', 'imran.abbas@gmail.com', 'Imran@123', '42301-7788990-1', 29, 'Karachi', '2025-10-23 07:00:00'),
(17, 'Nida Qureshi', 'nida.qureshi@yahoo.com', 'Nida@123', '35202-9900112-2', 23, 'Lahore', '2025-10-23 07:00:00'),
(18, 'Saad Anwar', 'saad.anwar@gmail.com', 'Saad@123', '61101-2233445-3', 25, 'Islamabad', '2025-07-14 07:00:00'),
(19, 'Iqra Javed', 'iqra.javed@gmail.com', 'Iqra@123', '37405-5566778-4', 20, 'Faisalabad', '2025-10-23 07:00:00'),
(20, 'Hassan Raza', 'hassan.raza@gmail.com', 'Hassan@123', '35201-6677889-5', 27, 'Lahore', '2025-10-23 07:00:00'),
(21, 'Aiman Zahra', 'aiman.zahra@gmail.com', 'Aiman@123', '42201-7788990-6', 24, 'Karachi', '2025-10-23 07:00:00'),
(22, 'Taha Aslam', 'taha.aslam@gmail.com', 'Taha@123', '61101-3344556-7', 26, 'Rawalpindi', '2025-10-23 07:00:00'),
(23, 'Sana Khalid', 'sana.khalid@yahoo.com', 'Sana@123', '35202-7788991-8', 22, 'Lahore', '2025-10-23 07:00:00'),
(24, 'Rehan Ahmed', 'rehan.ahmed@gmail.com', 'Rehan@123', '42301-9900112-9', 28, 'Karachi', '2025-10-23 07:00:00'),
(25, 'Mahnoor Ali', 'mahnoor.ali@gmail.com', 'Mahnoor@123', '37405-4455667-1', 21, 'Multan', '2025-10-23 07:00:00'),
(26, 'Daniyal Khan', 'daniyal.khan@gmail.com', 'Daniyal@123', '35201-2233445-2', 25, 'Peshawar', '2025-10-23 07:00:00'),
(27, 'Laiba Tariq', 'laiba.tariq@gmail.com', 'Laiba@123', '42201-7788993-3', 23, 'Karachi', '2025-10-23 07:00:00'),
(28, 'Nouman Sheikh', 'nouman.sheikh@gmail.com', 'Nouman@123', '61101-6677884-4', 29, 'Islamabad', '2025-10-23 07:00:00'),
(29, 'Hira Naveed', 'hira.naveed@gmail.com', 'Hira@123', '35202-9900115-5', 22, 'Lahore', '2025-10-23 07:00:00'),
(30, 'Fahad Jameel', 'fahad.jameel@gmail.com', 'Fahad@123', '42301-3344556-6', 26, 'Karachi', '2025-10-23 07:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `shipmentrecord`
--

CREATE TABLE `shipmentrecord` (
  `shipment_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `shipment_status` varchar(50) DEFAULT 'Pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` int(11) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `address` varchar(20) NOT NULL,
  `age` int(11) DEFAULT NULL CHECK (`age` > 17)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `name`, `email`, `password`, `address`, `age`) VALUES
(3, 'Ali', 'Ali@gmail.com', 'Ali123', 'DHA', 22),
(4, 'Ayaan', 'Ayaan@gmail.com', 'Ayaan123', 'Dha', 24),
(5, 'Eshan', 'Eshan@gmail.com', 'Eshan123', 'Saddar', 20),
(6, 'Ayaz', 'Ayaz@gmail.com', '123', 'DHA', 20),
(7, 'Talha', 'Talha@gmail.com', '123', 'DHA', 19),
(8, 'Munawar', 'Munawar@gmail.com', '123', 'Qayyomabad', 20),
(9, 'Mahad', 'Mahad@gmail.com', '123', 'Qayyomabad', 20);

-- --------------------------------------------------------

--
-- Structure for view `orderandshipmentstatus`
--
DROP TABLE IF EXISTS `orderandshipmentstatus`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `orderandshipmentstatus`  AS SELECT `students`.`name` AS `name`, `orders`.`order_id` AS `order_id`, `orders`.`product_name` AS `product_name`, `orders`.`product_qty` AS `product_qty`, `orders`.`product_price` AS `product_price`, `orders`.`user_id` AS `user_id`, `shipmentrecord`.`shipment_status` AS `shipment_status` FROM ((`students` join `orders` on(`orders`.`user_id` = `students`.`id`)) join `shipmentrecord` on(`shipmentrecord`.`user_id` = `students`.`id`)) ;

-- --------------------------------------------------------

--
-- Structure for view `productstock`
--
DROP TABLE IF EXISTS `productstock`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `productstock`  AS SELECT `category`.`category_name` AS `category_name`, `product`.`product_id` AS `product_id`, `product`.`product_name` AS `product_name`, `product`.`product_desc` AS `product_desc`, `product`.`product_qty` AS `product_qty`, `product`.`product_price` AS `product_price`, `product`.`category_id` AS `category_id` FROM (`category` join `product` on(`product`.`category_id` = `category`.`category_id`)) ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admission`
--
ALTER TABLE `admission`
  ADD PRIMARY KEY (`admission_id`),
  ADD KEY `student_id` (`student_id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`product_id`),
  ADD KEY `category_id` (`category_id`);

--
-- Indexes for table `registers`
--
ALTER TABLE `registers`
  ADD PRIMARY KEY (`rollno`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `cnic` (`cnic`);

--
-- Indexes for table `shipmentrecord`
--
ALTER TABLE `shipmentrecord`
  ADD PRIMARY KEY (`shipment_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admission`
--
ALTER TABLE `admission`
  MODIFY `admission_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `registers`
--
ALTER TABLE `registers`
  MODIFY `rollno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `shipmentrecord`
--
ALTER TABLE `shipmentrecord`
  MODIFY `shipment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `admission`
--
ALTER TABLE `admission`
  ADD CONSTRAINT `admission_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`);

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `students` (`id`);

--
-- Constraints for table `product`
--
ALTER TABLE `product`
  ADD CONSTRAINT `product_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `category` (`category_id`);

--
-- Constraints for table `shipmentrecord`
--
ALTER TABLE `shipmentrecord`
  ADD CONSTRAINT `shipmentrecord_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `students` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
