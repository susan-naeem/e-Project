<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <title>Hello, world!</title>
  </head>
  <body>


  <?php 

$data = [
    ["Name" => "Abc","Email" => "Abc@gmail.com","Password" => "Abc@123","Address" => "Dha"],
    ["Name" => "Talha","Email" => "Talha@gmail.com","Password" => "Talha@123","Address" => "Shah Faisal"],
    ["Name" => "Mahad","Email" => "Mahad@gmail.com","Password" => "Mahad@123","Address" => "Saddar"]
];


?>

<table class="table">
    <tr style="background-color: yellow;">
        <th>Email</th>
        <th>Password</th>
        <th>Address</th>
    </tr>

    <?php 

        foreach($data as $value){
            ?>

            <tr>
                    <td><?php echo $value['Email'] ?></td>
                    <td><?php echo $value['Password'] ?></td>
                    <td><?php echo $value['Address'] ?></td>
            </tr>
            <?php 
            
        }
    ?>
</table>


    

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

    
  </body>
</html>




