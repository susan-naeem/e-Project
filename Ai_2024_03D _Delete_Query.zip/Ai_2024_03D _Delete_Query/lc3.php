<?php 


// $data = ["Name" => "Abc","Email" => "Abc@gmail.com","Password" => "Abc@123","Address" => "Dha"];


// // echo $data['Email'].$data['Password'];

// foreach($data as $value){
//     echo $value."<br>";
// }



$data = [
    ["Name" => "Abc","Email" => "Abc@gmail.com","Password" => "Abc@123","Address" => "Dha"],
    ["Name" => "Talha","Email" => "Talha@gmail.com","Password" => "Talha@123","Address" => "Shah Faisal"],
    ["Name" => "Mahad","Email" => "Mahad@gmail.com","Password" => "Mahad@123","Address" => "Saddar"]
];

// echo $data[1]['Email'].$data[1]['Password'];

// foreach($data as $value){

//     foreach($value as $value1){
//             echo $value1;
//     }

//     echo "<br>";
// }


foreach($data as $value){

        echo $value['Email'].$value['Password']."<br>";
    
}





?>