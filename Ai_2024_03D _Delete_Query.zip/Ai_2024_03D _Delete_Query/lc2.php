<?php 

$age = 10; //Integer Data
$price = 250.6; // Float Data
$fullname = "Ahmed";
$is = false;

// var_dump($is);

$data = ["Ahmed","Ahmed@gmail.com",20,"DHA","44205-434343434-4"];

// echo "<pre>";
// var_dump($data);
// echo "</pre>";
//echo $data[0].$data[1];

//Print All Array Record

foreach($data as $a){
    echo $a;
}


?>