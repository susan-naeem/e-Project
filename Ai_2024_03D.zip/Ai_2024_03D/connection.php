<?php 
// Database Conection

$con = mysqli_connect("localhost","root","","ai_2025_03d");
// if($con == true){
//     echo "Connection Successful";
// } 


if(isset($_POST['register'])){

    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $address = $_POST['address'];
    $age = $_POST['age'];

    $EmailAlreadyExists = mysqli_query($con, "SELECT * FROM students WHERE email = '$email' ");

    if(mysqli_num_rows($EmailAlreadyExists) > 0){
    ?>
        <script>
            alert("Email Already Exists");
            location.assign("form-handling.php");
        </script>
        <?php 
    }else{
        $InsertData = mysqli_query($con, "INSERT INTO students (name, email, password, address, age) VALUES ('$name', '$email', '$password', '$address', '$age')");


        if($InsertData == true){

            ?>
                <script>
                    alert("Registration Successful");
                    location.assign("form-handling.php");
                </script>
            <?php
        }

    }
}
?>



<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<table class="table table-striped">
    <tr>
        <th>Name</th>
        <th>Email</th>
        <th>Password</th>
    </tr>

    <?php 
        $GetAllData = mysqli_query($con, "SELECT * FROM students");

        // var_dump($GetAllData);

        foreach($GetAllData as $data){
            ?>
                <tr>
                    <td><?php echo $data['name'] ?></td>
                    <td><?php echo $data['email'] ?></td>
                    <td><?php echo $data['password'] ?></td>
                </tr>
            <?php
        }
    ?>



</table>



<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>